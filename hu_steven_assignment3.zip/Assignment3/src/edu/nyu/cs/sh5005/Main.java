package edu.nyu.cs.sh5005;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.lang.StringBuilder;

/**
 * 
 * This is a class that opens up any text file specified by the user and analyze the tics occurrence
 * @author Steven Hu
 * @version 0.99
 *
 */


public class Main {
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * The class which executes first
	 * @param args
	 * @throws FileNotFoundException generates error message when certain file path is incorrect
	 */
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		
		//open user-input scanner
		Scanner input = new Scanner(System.in);
		//scan input file path
		System.out.print("What file would you like to open? Please enter your text's file path: ");
		String filePath = input.nextLine();
		
		//scan input file according to input file path
		Scanner file = new Scanner (new File(filePath));
		String[] brokenText = textBreaker(file);														//store the array of words from text file
		int wordCount = brokenText.length;
		System.out.print("What words would you like to search for? Separate your words with commas: ");
		String[] brokenKeyword = keywordInput(input);													//store the array of keywords from user input
		int [] occurrenceList = countOccurrence(brokenText, brokenKeyword);								//store the occurrences of each tic
		int occurrenceTotal = totalOccurrence(occurrenceList);											//store the total occurrences of all tics, feed into 
		double [] percentageList = countPercentage(occurrenceList, occurrenceTotal);					//store the percentage of (each tic occurrences)/(total tic occurrences) for each tic
		double density = densityOfTics(occurrenceTotal,wordCount);
		
		displayResult(occurrenceTotal,density,brokenKeyword,occurrenceList,percentageList);
		file.close();
		input.close();
	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * Breaks the text into an array consists of one word per cell
	 * @param fileVar calls the file scanner
	 * @return breakText a string array which contains all words in the text file (one word per cell)
	 * @throws FileNotFoundException generates error message when certain file path is incorrect
	 */
	private static String[] textBreaker(Scanner fileVar) throws FileNotFoundException {
		StringBuilder fileString = new StringBuilder();
		while (fileVar.hasNextLine()) {							
			fileString.append(fileVar.nextLine());				//text breaks down to lines and are appended to the StringBuilder
			fileString.append(" ");
		}
		String castFile = fileString.toString();
		String[] breakText = castFile.split(" ");				//string breaks down into words in an array
		for (int d = 0; d< breakText.length; d++) {				//lower-case everything, ensure consistency with the keywords
			breakText[d].toLowerCase();
		}
		
		return breakText;
	}
	
	/**
	 * Prompts the user to enter a list of keywords separated by commas, and splits the keywords into array
	 * @param inputVar calls the user-input scanner
	 * @return keywords an array which contains all the keywords entered in each cell
	 */
	private static String[] keywordInput(Scanner inputVar) {
		String keywordGroup = inputVar.nextLine();						//all tics input store here
		
		while (keywordGroup.contains(" ")){
			System.out.print("Please re-enter your keywords with commas but no spaces: ");
			keywordGroup = inputVar.nextLine();						//all tics input store here
		}
		
		String [] keywords = keywordGroup.split(",");					//split to an array of keywords

		for (int a = 0; a< keywords.length;a++) {						//lower-case everything, ensure consistency with the text
			keywords[a] = keywords[a].toLowerCase();
		}
		return keywords;
	}
	
	/**
	 * Compares the given keywords with the words in the text, count occurrence and record in an int array
	 * @param text the array of words from text file
	 * @param keyword the array of keywords from user input 
	 * @return occurrence a list of occurrences of each tic in file
	 */
	private static int[] countOccurrence(String[] text ,String[] keyword){
		int occurrence[] = new int[keyword.length];
		
		for (int i = 0; i < text.length; i++) {
			for (int a = 0; a< keyword.length; a++) {
				if (text[i].contains(keyword[a])) {
					occurrence[a]++;
				}
			}
		}
		
		return occurrence;
	}
	
	/**
	 * Calculate the percentage of specific tic over all tic occurrences
	 * @param occurrenceList a list of tic occurrences
	 * @param occurrenceTotal the grand total of all tic occurrences
	 * @return percentage a list of percentages of each tic in file
	 */
	private static double[] countPercentage(int[] occurrenceList, int occurrenceTotal){		
		
		double[] percentage = new double[occurrenceList.length];
		for(int a = 0; a< occurrenceList.length; a++) {
			if(occurrenceTotal != 0) {
				percentage[a] = 100.0 * occurrenceList[a]/occurrenceTotal;
			}
			else {
				percentage[a] = 0.0;
			}
		}
		
		return percentage;
	}
	
	/**
	 * Generates the sum of the number of all tics in the parameter array
	 * @param occurence calls a list of occurrences
	 * @return grand total of all tic occurrences
	 */
	private static int totalOccurrence(int[] occurrence){
		int total= 0;
		for (int q = 0; q < occurrence.length; q++) {
			total += occurrence[q];
		}
		return total;
	}
	
	/**
	 * Calculates the density of all the tics from all the words in the specified file
	 * @param occurrenceTotal the grand total of all tic occurrences
	 * @param wordCount the number of words in file
	 * @return density the density of tics in file in "double"
	 */
	private static double densityOfTics(int occurrenceTotal, int wordCount) {
		double density = 1.0*occurrenceTotal/wordCount;
		return density;
	}
	
	
	private static void displayResult(int totalOccurrence, double density, String[] keyword, int[] listOccurrence, double[] listPercentage){
		System.out.println("\n" + "...............................Analyzing text................................." + "\n");
		System.out.println("Total number of tics: " + totalOccurrence);
		System.out.printf("Density of tics: %.1f\n", density);
		System.out.println("\n" + "...............................Tic breakdown.................................." + "\n");
		for(int p = 0; p< listOccurrence.length;p++) {
			System.out.println(String.format("%-10s", keyword[p]) + String.format("%-3s", "/") + String.format("%5d", listOccurrence[p]) + String.format("%-5s", " occurrences") + String.format("%5s", "/") + String.format("%5d", Math.round(listPercentage[p]))+ "% of all tics");
		}
	}
	

}

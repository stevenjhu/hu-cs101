package edu.nyu.cs.sh5005;
import java.util.Scanner;


/**
 * Program to simulate the game of BlackJack.
 *
 * @author Steven Hu
 * @version 1.0 
 */
public class Main {

	
	/**
	 * Outputs a simulation of BlackJack to the console.
	 * @param args String array of any arguments supplied when running the program.
	 * @return void main functions cannot be returned because the type of class is void
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 0; // define the times of repetition of player's card drawn
		int z = 0; //define the times of repetition of computer's card drawn
		boolean y = false; //for closing the "hit or stop" loop
		boolean comHit = false;
		int playerSum = 0;
		int comSum = 0;
		int playerNumOfCards = 2;
		int comNumOfCards = 2;
		int hitChance =0; //percentage out of 100
		int array[] = new int[11];
		// lowest number is 2 and the lowest you can get is 10*2=20, one more will guarantee the computer busted.
		boolean playerInstantLose = false;
		boolean busted = false;
		boolean comReach21 = false;
		
		
		System.out.println("Welcome to Steven's simulator of BlackJack!");
		System.out.println();
		
		System.out.println("Start dealing the dealer's cards...");
		//Write dealer's code
		while(z<2) {
			array[z] = GiveNum();
			comSum+=array[z];
			if (comSum== 21) {
				comReach21 = true;
			}
			z++;
		} // 0, 1 slot filled in array
		System.out.println("The dealer's cards are dealt.");
		
		System.out.println("Start dealing your cards...");
		System.out.print("Your cards are: ");
		while(x < 2) { // start the dealing of the user's card
			int randNum1 = GiveNum();
			System.out.print(randNum1+ " ");
			playerSum+=randNum1;
			x++;
		} 				
		System.out.println(""); // return 
		System.out.println("This is your sum now: " + playerSum); // show the sum
		if(playerSum != 22) { // only way to bust yourself with two cards
			Scanner input1 = new Scanner(System.in);
			
			while(y == false) {
				System.out.print("These are your cards and sum, would you like to hit? (y/n) ");
				String a = input1.next();
				
				switch (a) {
				case "y" : 
					int randNum2 = GiveNum();
					System.out.println("The card drawn is: " + randNum2);
					playerSum += randNum2;
					playerNumOfCards++; // add to the number of cards in player's hand
					System.out.println("This is your new sum: " + playerSum);
					if (playerSum > 21) {
						System.out.println("You just busted! Booooooo!!!");
						y = true;
						busted =true;
					}
					break;
				case "n" :
					y = true;
					break;
				default: 
					System.out.println("Invalid input. Please enter either \"y\" or \"n\".");
					break;
				}
			}
			input1.close();
			
			//Write dealer's code
			if(!busted) {
				System.out.println();
				System.out.println("The dealer is choosing to hit or stop...");
				while (comHit == false && !comReach21) {
					//rule 1: if 100% sure it is not going to bust, hit
					if (comSum + 11 <= 21) {
						if (comNumOfCards > 3) {
							System.out.println("The dealer hits again!");
						}
						else {
							System.out.println("The dealer hits!");
						}
						
						array[comNumOfCards] = GiveNum();
						comSum += array[comNumOfCards];
						if (comSum > 21) {
							comHit = true;
						}
						comNumOfCards++;
						
						
					}
					else if (comSum== 21) {
						comReach21 = true;
					}
					else {
						//post-100%-probability-of-busting-logic
						if(21-comSum <= 4) {
							hitChance = (21-comSum)*3;
						}
						else {
							hitChance = (21-comSum) * 10;
						}
						
						if (playerNumOfCards > 3 && hitChance +10 <= 100) {
							hitChance += 10;
						}
						if (playerNumOfCards >= 5 && hitChance +20 <= 100) {
							hitChance += 20;
						}
						int calcChance = (int)(Math.random()*100)+1; 
						//0% chance means it cannot be chosen by the random function, therefore not in the range
						
						if (calcChance <= hitChance) {
							System.out.println("The dealer hits again!");
							array[comNumOfCards] = GiveNum();
							comSum += array[comNumOfCards];
							if (comSum > 21) {
								comHit = true;
							}
							comNumOfCards++;
						}
						else {
							System.out.println("The dealer stops.");
							System.out.println();
							comHit = true;
						}
						
					}
					
				}
			}//the dealer will automatically win if the user busts
			
		}
		else {
			System.out.println("You just busted! Booooooo!!!");
			playerInstantLose = true;
		}
		
		
		
		//Show dealer's hand
		System.out.print("The dealer's hand is: ");
		for (int a=0; a <comNumOfCards; a++) {
			System.out.print(array[a] + " ");
		}
		System.out.println();
		System.out.println("The sum of the dealer's cards is: " + comSum);
		System.out.println();
		
		//Calculate winner
		if (((playerSum == 21 && comSum != 21)||(playerSum < 21 && playerSum > comSum)|| comSum >21)&& playerSum <=21) {
			System.out.println("You win! Congratulation! You beat my bot!");
		}
		else if (playerSum == comSum) {
			System.out.println("You get a tie! You gotta do better than that!");
		}
		else if ((comSum == 21 && playerSum != 21) || (comSum < 21 && comSum > playerSum )|| playerSum > 21 ||playerInstantLose){
			System.out.println("You lost! Try again next time!");
		}
		
		
		System.out.println("Thank you for playing Steven's simulator of BlackJack. Hope to see you again soon!");
		
	}
	
	public static int GiveNum() { //drawn a random card with a value from 2 to 11
		int randNum = 0;
		randNum = (int)(Math.random()*10)+2;
		return randNum;
	}
	
}

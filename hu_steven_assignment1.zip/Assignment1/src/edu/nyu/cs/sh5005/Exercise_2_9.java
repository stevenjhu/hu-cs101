package edu.nyu.cs.sh5005;
import java.util.Scanner;
/**
 * A program that calculate the average acceleration
 * @author Steven Hu
 * @version 1.0
 *
 */


public class Exercise_2_9 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter v0, v1, and t: ");
		double v0 = input.nextDouble();
		double v1 = input.nextDouble();
		double t = input.nextDouble();
		//System.out.println(v0+v1+t);
		input.close();
		
		double a = (v1-v0)/t;
		System.out.print("The average acceleration is ");
		System.out.printf("%.4f", a);
	}
		//hoorayyyyy
}

package edu.nyu.cs.sh5005;
import java.util.Scanner;

/**
 * A program that calculate the tips
 * @author Steven Hu
 * @version 1.0
 *
 */

public class Exercise_2_5 {

	public static void main(String[] args) {
		Scanner input1 = new Scanner(System.in);
		System.out.print("Enter the subtotal: ");
		double subtotal = input1.nextDouble();
		System.out.print("Enter the gratuity rate(integer without'%'sign): ");
		double tipRate = input1.nextDouble();
		input1.close();
		
		double total = subtotal * (1.0 + tipRate/100.0);
		double gratuity = total - subtotal;
		System.out.println("The gratuity is $" + gratuity + " and total is $" + total);
		
	}

}

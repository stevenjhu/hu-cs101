package edu.nyu.cs.sh5005;

/**
 * A program that calculate the approximate value of pi
 * @author Steven Hu
 * @version 1.0
 *
 */

public class Exercise_1_7 {

	public static void main(String[] args) {
		double result1 = 4.0*(1.0-1.0/3.0+1.0/5.0-1.0/7.0+1.0/9.0-1.0/11.0);
		double result2 = 4.0*(1.0-1.0/3.0+1.0/5.0-1.0/7.0+1.0/9.0-1.0/11.0+1.0/13.0);
		
		System.out.println("The first result is: " + result1);
		System.out.println("The second result is: " + result2);
		
		//haha it works, right?
	}

}

package edu.nyu.cs.sh5005;
import java.util.Scanner;

/**
 * A program that calculate the account value overtime
 * @author Steven Hu
 * @version 1.0
 *
 */

public class Exercise_2_13 {

	public static void main(String[] args) {
		//Save $100 each month
		//interest rate 5%
		//monthly interest rate is 0.05/12 = 0.00417
		
		//1. Prompt to write monthly saving amount
		//2. Display account value after 6 months
		
		System.out.print("Enter the monthly saving amount: ");
		Scanner input = new Scanner(System.in);
		double saving = input.nextDouble();
		input.close();
		double value= 0.0;// account Value
		double monthly_interest_rate = 0.00417;
		
		for(int i = 0; i<6; i++) {
			value = (value + saving)*(1 + monthly_interest_rate);
		}
		System.out.print("After the sixth month, the account value is $");
		System.out.printf( "%.2f",value);
	}

}

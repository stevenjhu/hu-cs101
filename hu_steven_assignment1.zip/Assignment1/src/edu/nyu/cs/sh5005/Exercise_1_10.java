package edu.nyu.cs.sh5005;

/**
 * A program that calculate the average speed
 * @author Steven Hu
 * @version 1.0
 *
 */

public class Exercise_1_10 {

	public static void main(String[] args) {
		int distance = 14; //km
		double km_to_mile = 1/1.6;
		//System.out.println(distance*km_to_mile);
		double timeSpent = 45.0/60.0 + 30.0/3600.0; //hr
		//System.out.println(timeSpent);
		
		double avgSpeed = distance*km_to_mile/timeSpent;
		
		
		System.out.print("The average speed of this runner is: ");
		System.out.printf ("%.2f", avgSpeed);
		System.out.println(" mph");
	}

}

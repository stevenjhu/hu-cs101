package edu.nyu.cs.sh5005;

/**
 * A program that calculate the population for each year
 * @author Steven Hu
 * @version 1.0
 *
 */

public class Exercise_1_11 {

	public static void main(String[] args) {
		//One birth every 7 seconds
		//One death every 13 seconds
		//One new immigrant every 45 seconds
		
		//Display the population of each of the next 5 years
		//Current population: 312032486
		//365 days/year
		
		
		//int arrayForpop[] = new int[5];
		int second_in_a_year = 365 * 24 * 60 * 60;
		int birth = 7;
		int death = 13;
		int immigrant = 45;
		int population = 312032486;
		
		for(int i = 0; i<5; i++) {
			population = population + second_in_a_year/birth - second_in_a_year/death + second_in_a_year/immigrant;
			System.out.println("The " + (i+1)+ "st " + "year's population is: " + population);
		}
		
		//Thank god this works
		
	}

}

package edu.nyu.cs.sh5005;
import java.util.Scanner;
import java.io.FileNotFoundException;

public class SearchAlgorithm {
	private static String LJustify = "%-30s";
	
	/**
	 * Compute the search result that are not commands
	 * @param scan user input scanner
	 * @param keywords user input in an array
	 * @throws FileNotFoundException
	 */
	public static void displayResult(Scanner scan,String[] keywords) throws FileNotFoundException{
		if (keywords.length == 2) {
			switch(keywords[0]) {
				case "helmusg":
					helmetUsage(scan, keywords,keywords[1]);
					break;
				case "laneanalysis":
					laneAnalysis(scan,keywords);
					break;
				default:
					Main.printError();
					Main.askForMore(scan);
			}//switch
		}//if
		else {
			cyclistVolume(keywords[1],keywords[2],scan);
		}//else(under the circumstance of calling in the main function, keywords.length has to be 3 to be able to execute the "else" function here)
	}
	
	/**
	 * Displays the data of total helmet usage of one gender according to the user input 
	 * @param scan user input scanner
	 * @param keywords an array of keywords put in by users
	 * @param gender determiner of showing male-related or female-related data
	 * @throws FileNotFoundException
	 */
	public static void helmetUsage(Scanner scan, String[] keywords, String gender) throws FileNotFoundException {
		String[][]fileArray = ReadFile.fileArray();
		int numberOfRows =fileArray.length;
		boolean genderDetermined;
		
		
		System.out.printf(LJustify,fileArray[0][0]); //Location ID
		System.out.printf(LJustify,fileArray[0][6]); //Year
		if(gender.equals("female")) {
			genderDetermined = true; //O is female
			System.out.printf(LJustify+"\n",fileArray[0][18] ); //Female with Helmet
		}else {
			genderDetermined = false; //X is male
			System.out.printf(LJustify+"\n",fileArray[0][19]); //Male with Helmet
		}
		int i = 1;
		boolean loopBreak = false;
		while (i<numberOfRows && !loopBreak) {
			System.out.printf(LJustify,fileArray[i][0]);
			System.out.printf(LJustify,fileArray[i][6]);
			if(genderDetermined) {
				System.out.printf(LJustify+"\n",fileArray[i][18]);
			}else {
				System.out.printf(LJustify+"\n",fileArray[i][19]);
			}
			loopBreak = hitForMore(scan,i,loopBreak);
			i++;
		}
		System.out.println("[No more data]");
		
	}
	
	/**
	 * Display the number of cyclists who bike within lanes, who bike in adjacent lanes, and who bike in other lanes of a specific location specified by the user
	 * @param scan user input scanner
	 * @param keywords an array of keywords put in by users
	 * @throws FileNotFoundException
	 */
	public static void laneAnalysis(Scanner scan,String[]keywords) throws FileNotFoundException {
		String[][]fileArray = ReadFile.fileArray();
		int numberOfRows = fileArray.length;
		
		
		String temp = "";
		int startRow = 0;
		int endRow = 0;
		boolean startedInCorrectID = false;
		for (int a = 1;a < numberOfRows&&fileArray[a]!=null;a++) {
			if(fileArray[a][0].equals(keywords[1])) {
				if(!startedInCorrectID) {
					startRow = a;
				}
				startedInCorrectID = true;
				if(startedInCorrectID && temp!=fileArray[a][0]&& temp !="") {
					endRow = a-1;
				}
			}
			temp = fileArray[a][0];
		}
		
		//print the titles
		System.out.printf(LJustify+LJustify+LJustify+LJustify+"\n", fileArray[0][0], fileArray[0][10], fileArray[0][11], fileArray[0][12]);
		
		boolean loopBreak = false;
		int start = startRow;
		int end = endRow;
		int linePrintCounter = 0;
		
		while(start<=end&&!loopBreak) {
			System.out.printf(LJustify+LJustify+LJustify+LJustify+"\n", fileArray[start][0], fileArray[start][10], fileArray[start][11], fileArray[start][12]);
			linePrintCounter++;
			hitForMore(scan,linePrintCounter,loopBreak);
			start++;
		}
		System.out.println("[No more data]");
	}//laneAnalysis
	
	/**
	 * Displays the total volume of cyclist within a range of years specified by the user
	 * @param min the lower bound of the year range
	 * @param max the upper bound of the year range
	 * @param scan user input scanner
	 * @throws FileNotFoundException
	 */
	public static void cyclistVolume(String min, String max, Scanner scan) throws FileNotFoundException{
		String[][] fileArray = ReadFile.fileArray();
		int [] displayIndex =new int[fileArray.length];
		int minYear = Integer.parseInt(min);
		int maxYear = Integer.parseInt(max);
		int counterInIndexArray = 0;
		
		for (int a= 1;a < fileArray.length&&fileArray[a] != null; a++) {
			int oneYear = Integer.parseInt(fileArray[a][6]);
			if (oneYear<=maxYear && oneYear >=minYear) {
				displayIndex[counterInIndexArray]=a;
				counterInIndexArray++;
			}
			
		}
		System.out.printf(LJustify+LJustify+LJustify+"\n", fileArray[0][0],fileArray[0][6],fileArray[0][9]); //titles
		boolean loopBreak = false;
		for (int index =0; index<displayIndex.length&&!loopBreak;index++) {
			System.out.printf(LJustify+LJustify+LJustify+"\n", fileArray[displayIndex[index]][0],fileArray[displayIndex[index]][6],fileArray[displayIndex[index]][9]);
			loopBreak = hitForMore(scan,index,loopBreak);
		}
		System.out.println("[No more data]");
	}
	
	/**
	 * Returns a boolean value which value depends on if the user has typed anything. Help determine if the user want to see more than 10 results or not
	 * @param scan user input scanner
	 * @param counter number of iterations through the loop where this function is called
	 * @param loopBreak the initial value of the loop
	 * @return loopBreak value to set the flag of a loop
	 */
	public static boolean hitForMore(Scanner scan, int counter, boolean loopBreak) {
		if(counter%10 == 0&&counter !=0) {
			System.out.println("..hit enter to see more, or type anything and enter to stop..");
			String enter = scan.nextLine();
			if (!enter.equals("")) {
				loopBreak = true;
			}
		}
		return loopBreak;
	}
}

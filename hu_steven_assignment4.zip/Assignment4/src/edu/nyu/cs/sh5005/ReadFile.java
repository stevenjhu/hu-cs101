package edu.nyu.cs.sh5005;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * A class that has a function for reading files
 *
 */
public class ReadFile {
	static int numberOfRows = 0; //number of lines in the file, can be used everywhere in this program
	
	/**
	 * Returns a 2d-array with the file broken down into "rows" and "columns"
	 * @return an array with the entire content of the file
	 * @throws FileNotFoundException
	 */
	public static String[][] fileArray() throws FileNotFoundException {
		Scanner file = new Scanner (new File("src/bikes.csv"));
		String entireFile = "";
		
		//put file data into 2d-array (rows and columns)
		while(file.hasNextLine()) {
			String line = file.nextLine();
			entireFile += (line + "\n");
			numberOfRows++;
		}//while
		
		String [] lineArray = entireFile.split("\n");
		String [][] fileArray = new String[numberOfRows][];
		
		for(int i = 0; i< lineArray.length; i++) {
			String[] dataCell = lineArray[i].split(",");
			fileArray[i] = dataCell;
		}
		
		
		file.close();
		return fileArray;
	}
	
	
	
}

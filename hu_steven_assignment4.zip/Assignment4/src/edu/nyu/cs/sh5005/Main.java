package edu.nyu.cs.sh5005;
import java.util.Scanner;
import java.io.FileNotFoundException;

/**
 * This is the main class that deal with the display of the results according to the user's input. 
 * @author Steven Hu
 * @version 0.9
 */
public class Main {
	
	private static String[] acceptableCommands = {
			"---------------------------------------------------------------------------------------------------------------------------------------------------",
			"help					Show a list of valid commands",
			"loc					Show a list of locations and their IDs respectively",
			"end					End the program",
			"cycVolume,(MinimumYear),(MaximumYear)	Search for the volume of cyclists in a given range of years E.g. cycVolume,2005,2007",
			"helmUsg,Male/Female			Search for the total number of helmet usage of male or female E.g.helmUsg,Male",
			"laneAnalysis,(LocationID)		Search for the number of bikers in biking lanes, adacent lanes, or other lanes of a particular location E.g. laneAnalysis,1",
			"---------------------------------------------------------------------------------------------------------------------------------------------------"
	};
	private static boolean flag = true; // flag for the user response while loop
	
	public static void main(String[] args) throws FileNotFoundException{
		// TODO Auto-generated method stub
		System.out.println("Welcome to the NY Manhattan Bike Info Search App!");
		System.out.println("This app displays all the columns of data from https://data.cityofnewyork.us/Transportation/NYCDCP-Manhattan-Bike-Counts-On-Street-Weekday/qfs9-xn8t");
		System.out.println("We can help you find: ");
		System.out.println("	1. The volume of cyclists in a given range of years");
		System.out.println("	2. The total number of helmet usage of male or female");
		System.out.println("	3. The number of bikers in biking lanes, adacent lanes, or other lanes of a particular location");
		
		Scanner scan = new Scanner(System.in);
			
		
		//while loop that keep asking the user if he/she wish to see more data or start another search or end the program
		while (flag) {
			System.out.println("Please enter one of the given keyword to initiate a search (type 'help' for a list of valid inputs, separate your keywords with commas): ");
			String input = scan.nextLine().toLowerCase(); // input keywords
			String[] inputArray = input.split(",");
			executeCommand(scan, inputArray);
			
		}//while
		
	}//main
	
	/**
	 * Determine the type of the keywords input and execute functions respectively
	 * @param scan user input scanner
	 * @param keywords an array of keywords put in by users
	 * @throws FileNotFoundException
	 */
	public static void executeCommand(Scanner scan, String[] keywords) throws FileNotFoundException {
		
		if(keywords.length == 1) {
			//switch function, compare the keyword with the pool of commands available and perform actions 
			commandKeyword(scan,keywords);
		}//one keyword detected
		else if (keywords.length == 2 || keywords.length == 3) {
			SearchAlgorithm.displayResult(scan,keywords);
		}//two or three keywords detected
		else {
			printError();
			askForMore(scan);
		}//invalid input
	}
	
	/**
	 * Execute functions when keywords are commands
	 * @param scan user input scanner
	 * @param keywords an array of keywords put in by users
	 * @throws FileNotFoundException
	 */
	public static void commandKeyword(Scanner scan, String[] keywords) throws FileNotFoundException {
		boolean noMoreIteration = false;
		
		switch (keywords[0]) {
			case "help":
			case "'help'":
				for (String command : acceptableCommands) {
					System.out.println(command);
				}
				break;
			case "loc":
			case "'loc'":
				displayLocation();
				break;
			case "end":
				noMoreIteration = true;
				System.out.println("Thank you for using the NY Manhattan Bike Info Search App! Have a nice day!");
				break;
			default:
				printError();
		}
		
		if(!noMoreIteration) {
			askForMore(scan);
		}
		else {
			flag = false;
		}
	}
	
	/**
	 * When user inputs 'loc' as the keyword, display a list of location IDs with their respective locations
	 * @throws FileNotFoundException
	 */
	public static void displayLocation() throws FileNotFoundException{
		String [][] fileArray = ReadFile.fileArray();
		String previousCell = "";
		String locationString = "";
		
		for (int a = 0; a < ReadFile.numberOfRows;a++) {
			String value = fileArray[a][3];
			if(!value.equals(previousCell)) {
				locationString += (value+"\n");
				previousCell = value;
			}
		}
		String[] locations = locationString.split("\n");
		
		//print
		System.out.printf("%-15s", "Location ID");
		System.out.println("Location");
		for(int b = 1; b< locations.length;b++) {
			System.out.printf("%-15d", b);
			System.out.println(locations[b]);
		}
	}
	
	/**
	 * Print an error message whenever a user puts in an invalid input
	 */
	public static void printError() {
		System.out.println("Invalid input. Type 'help' for valid inputs.");
	}

	/**
	 * Recursive function which ask the user to put in addition keyword(s)
	 * @param scan reference of the user input scanner
	 * @throws FileNotFoundException Throws an error message when file is not found
	 */
	public static void askForMore(Scanner scan) throws FileNotFoundException{
		System.out.println("\n"+"What would you like to do next? Please enter one of the given keyword to initiate a search (type 'help' for a list of valid inputs, separate your keywords with commas):");
		String moreInput = scan.nextLine().toLowerCase();
		String[] moreKeywords = moreInput.split(",");
		executeCommand(scan, moreKeywords);
	}
}//Main

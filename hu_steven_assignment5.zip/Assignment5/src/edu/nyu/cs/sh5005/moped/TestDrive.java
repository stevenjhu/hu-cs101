package edu.nyu.cs.sh5005.moped;
import java.util.Scanner;


/**
 * The class that handles the interactions between the user and the virtual Moped
 * @author Steven Hu (worked with Sherry Ma)
 * @version 0.99
 */
public class TestDrive {
	
//	static boolean[][] location = new boolean[200][10]; //true if Moped arrive 
	private final static String[] acceptableCommands = {
			"go left",
			"go right",
			"straight on",
			"back up",
			"how we doin'?",
			"park",
			"go to Petite Abeille",
			"help"
	};
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to your most extraordinary Moped experience! As you roam around Manhattan, several ads will help you get a better perspective of NYC!");
		Scanner scan = new Scanner(System.in);
		
		boolean goOn = true;
		Moped user = new Moped(10,5,"South","User");
		System.out.printf("%s is now at %dth St. and %dth Ave...heading %s\n",user.getName(),user.getLoc()[0],user.getLoc()[1],user.getDirection());

		while(goOn) {
			goOn = nextStep(scan,goOn, user);
		}
		
	}
	
	public static boolean nextStep(Scanner scan, boolean goOn, Moped user) {
		System.out.println("Where you would you like to go next? Say \"help\" if needed.");
		String response = scan.nextLine().toLowerCase();
		
		switch(response) { //switch does not take array values
			case "go left":
			case "go right":
			case "straight on":
			case "back up":
				if(user.getFuelLevel()>0) {
					boolean keepMoving = true; // so the while loop always execute once
					while(keepMoving) {
						keepMoving = false;
						
						user.move(response,user.getLoc());
						user.printLoc(user.getLoc()[0],user.getLoc()[1]);
						printAd(user.getLoc()[0],user.getLoc()[1]);
						
						if(user.outOfBound(user.getLoc()[0], user.getLoc()[1])) {
							keepMoving = true; // run another iteration if 
						}
					}
				}
				else {
					goOn = outOfGas(goOn);
				}
				break;
			case "how we doin'?":
				System.out.printf("The fuel level is currently at %d%%\n", user.getFuelLevel());
				break;
			case "fill 'er up":
				user.fillTank();
				break;
			case "park":
				System.out.println("The Moped is parked along the sidewalk. Thank you for riding!");
				goOn = false;
				break;
			case "go to petite abeille":
				if(user.getFuelLevel()>0) { //check before going
					user.goPA(user.getLoc());
				}
				else {
					goOn = outOfGas(goOn);
				}
				break;
			case "help":
				System.out.println("These are the acceptable commands:");
				for (String command : acceptableCommands) {
					System.out.println(command);
				}
				break;
			default:
					System.out.println("Invalid input. Please try again.");
		}
		return goOn;
	}
	public static void printAd(int st, int ave) {
		if(st == 79 && ave == 8)
			System.out.println("	The American Museum of Natural History is currenly holding a rare jewel exhibition right now! Why don't you check it out!");
		if(st == 74 && ave == 1) 
			System.out.println("	Memorial Sloan Kettering is your best way of fighting cancer!");
		if(st == 12 && ave == 4)
			System.out.println("	All books at the Strand are having a 30% off discount!");
		if(st == 3 && ave == 6)
			System.out.println("	The best place to have a hangout with delicious treats only at Fayda Coffee Tea Cookies Cake shop!");
	}
	public static boolean outOfGas(boolean goOn) {
		System.out.println("The Moped is out of gas. The trip is over!");
		goOn = false;
		return goOn;
	}
	
}

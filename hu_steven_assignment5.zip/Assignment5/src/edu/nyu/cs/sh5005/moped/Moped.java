package edu.nyu.cs.sh5005.moped;

public class Moped {
	private int[] location = new int[2]; // 0 is st, 1 is ave
	private String direction;
	private static int fuelLevel = 20;
	private String name;
//	private final static String[] orientations = {
//		"North",
//		"West",
//		"South",
//		"East"
//	};
	
	public Moped() {
		
	}
	
	public Moped(int st, int ave, String direction, String name) {
		int[] loc = {st,ave};
		this.initialPosition(loc);
		this.setDirection(direction);
		this.setName(name);
	}
	
	public int[] initialPosition(int[] location) {
		this.location[0] = location[0];
		this.location[1] = location[1];
		return location;
	}
	
	public int[] move(String response, int[] location) {
		int st = location[0]; //for readability
		int ave = location[1];//for readability
		
		if (response.equals("go left")) {
			//though seems redundant, switch does not take array value, and if/else requires longer code
			switch (direction) {  
				case "North":
					ave = this.addAve(ave,response);
					break;
				case "West":
					st = this.minusSt(st,response);
					break;
				case "South":
					ave = this.minusAve(ave,response);
					break;
				case "East":
					st = this.addSt(st,response);
			}
		}
		else if (response.equals("go right")) {
			switch (direction) {
			case "North":
				ave = this.minusAve(ave, response);
				break;
			case "West":
				st = this.addSt(st, response);
				break;
			case "South":
				ave = this.addAve(ave, response);
				break;
			case "East":
				st = this.minusSt(st, response);
			}
		}
		else if (response.equals("straight on")) {
			switch (direction) {
			case "North":
				st = this.addSt(st, response);
				break;
			case "West":
				ave = this.addAve(ave, response);
				break;
			case "South":
				st = this.minusSt(st, response);
				break;
			case "East":
				ave = this.minusAve(ave, response);
			}
		}
		else{
			switch (direction) {
			case "North":
				st = this.minusSt(st, response);
				break;
			case "West":
				ave = this.minusAve(ave, response);
				break;
			case "South":
				st = this.addSt(st, response);
				break;
			case "East":
				ave = this.addAve(ave, response);
			}
		} 
		//assign the values of st # and ave # back to the location array
		location[0] = st;
		location[1] = ave;
		
		if(!this.outOfBound(st, ave)) {
			lesserGas();
		}
		return location;
	}
	public String setDirection(String direction) {
		this.direction = direction;
		return direction;
	}
	public int lesserGas() {
		fuelLevel--; // cannot be 0 because when called, in TestDrive.main, the prerequisite is fuelLevel is not 0
		return fuelLevel;
	}
	public int fillTank() {
		fuelLevel = 20;
		System.out.println("Tank filled.");
		return fuelLevel;
	}
	public String setName(String name) {
		this.name = name;
		return name;
	}
	public int[] goPA (int[] location) { 
		int st = location[0];
		int ave = location[1];
		
		String response = "straight on";
		boolean keepGoingSt = true;
		boolean keepGoingAve = true;
		
		while(keepGoingSt) {
			if(st > 17) {
				st = this.minusSt(st, response);
				this.setDirection("South");
				this.printLoc(st,ave);
			}
			else if (st < 17){
				st = this.addSt(st, response);
				this.setDirection("North");
				this.printLoc(st,ave);
			}
			else {
				keepGoingSt = false;
			}
		}
		while(keepGoingAve) {
			if(ave > 6) {
				ave = this.minusAve(ave, response);
				this.setDirection("East");
				this.printLoc(st,ave);
			}
			else if (ave < 6){
				ave = this.addAve(ave, response);
				this.setDirection("West");
				this.printLoc(st,ave);
			}
			else {
				keepGoingAve = false;
			}
		}
		
		
		location[0] = st;
		location[1] = ave;
		System.out.println("	You have arrived at Petite Abeille!");
		
		return location;
	}
	
	public int[] getLoc() {
		return location;
	}
	public String getDirection() {
		return direction;
	}
	public int getFuelLevel() {
		double percentage = fuelLevel/20.0 *100;
		int fuelLevelPercentage = (int) Math.round(percentage);
		return fuelLevelPercentage;
	}
	public String getName() {
		return name;
	}
	
	public int addSt(int st, String response) {
		if(!outOfSt(st)) {
			st++;
			if (response.equals("go left") || response.equals("go right")) {
				this.setDirection("North");
			}
		}
		else {
			this.outOfBoundMessage();
		}
		return st;
	}
	public int minusSt(int st, String response) {
		if(!outOfSt(st)) {
			st--;
			if (response.equals("go left") || response.equals("go right")) {
				this.setDirection("South");
			}
		}
		else {
			this.outOfBoundMessage();
		}
		return st;
	}
	public int addAve(int ave, String response) {
		if(!outOfAve(ave)) {
			ave++;
			if (response.equals("go left") || response.equals("go right")) {
				this.setDirection("West");
			}
		}
		else {
			this.outOfBoundMessage();
		}
		return ave;
	}
	public int minusAve(int ave, String response) {
		if(!outOfAve(ave)) {
			ave--;
			if (response.equals("go left") || response.equals("go right")) {
				this.setDirection("East");
			}
		}
		else {
			this.outOfBoundMessage();
		}
		return ave;
	}
	
	public boolean outOfSt(int st) {
		boolean out = false;
		if(st > 200 || st < 0) {
			out = true;
		}
		return out;
	}
	public boolean outOfAve(int ave) {
		boolean out = false;
		if(ave > 10 || ave < 0) {
			out = true;
		}
		return out;
	}
	public boolean outOfBound(int st, int ave) {
		boolean out = false;
		if ((st<0&&st>200)||(ave<0&&ave>10)) {
			out = true;
		}
		return out;
	}
	public void outOfBoundMessage() {
		System.out.println("You cannot go further that way. Try go somewhere else!");
	}
	public void printLoc(int st, int ave) {
		System.out.printf("%s is now at %dth St. and %dth Ave...heading %s\n", this.getName(),st,ave,this.getDirection());
	}
}
